import sqlite3
from pathlib import Path
from typing import List, Tuple

from . import DB_PATH

CATEGORIES = ["BAT", "BOW", "AR", "WK"]

# -------------------- connection helpers ---------------------------

def get_connection() -> sqlite3.Connection:
    """Return a connection to the package-local sqlite DB."""
    return sqlite3.connect(DB_PATH)

# -------------------- initial schema + seed ------------------------

SEED_PLAYERS = [
    ("Virat Kohli", "BAT", 100, 250, 12000, 43, 62),
    ("Rohit Sharma", "BAT", 95, 240, 10000, 30, 50),
    ("Shikhar Dhawan", "BAT", 85, 150, 6500, 17, 35),
    ("KL Rahul", "WK", 90, 85, 4500, 5, 18),
    ("MS Dhoni", "WK", 99, 350, 10773, 10, 73),
    ("Hardik Pandya", "AR", 88, 80, 1500, 0, 9),
    ("Ravindra Jadeja", "AR", 92, 160, 2200, 0, 13),
    ("Jasprit Bumrah", "BOW", 97, 100, 60, 0, 0),
    ("Bhuvneshwar Kumar", "BOW", 90, 120, 110, 0, 0),
]


def init_db() -> None:
    con = get_connection()
    cur = con.cursor()
    # create tables
    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS stats (
            player   TEXT PRIMARY KEY,
            ctg      TEXT,
            value    INTEGER,
            matches  INTEGER,
            runs     INTEGER,
            hundreds INTEGER,
            fifties  INTEGER
        );
        CREATE TABLE IF NOT EXISTS teams (
            name    TEXT PRIMARY KEY,
            players TEXT,
            value   INTEGER
        );
        CREATE TABLE IF NOT EXISTS match (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            name     TEXT,
            player   TEXT,
            scored   INTEGER,
            faced    INTEGER,
            fours    INTEGER,
            sixes    INTEGER,
            bowled   INTEGER,
            maiden   INTEGER,
            given    INTEGER,
            wkts     INTEGER,
            catches  INTEGER,
            stumping INTEGER,
            run_out  INTEGER
        );
        """
    )
    # seed players once
    cur.execute("SELECT COUNT(*) FROM stats")
    if cur.fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO stats VALUES (?,?,?,?,?,?,?)", SEED_PLAYERS
        )
    con.commit()
    con.close()


# -------------------- simple query helpers -------------------------

def get_players(ctg: str) -> List[Tuple[str, int]]:
    con = get_connection(); cur = con.cursor()
    cur.execute("SELECT player,value FROM stats WHERE ctg=? ORDER BY player", (ctg,))
    rows = cur.fetchall()
    con.close()
    return rows


def save_team(name: str, players: List[str], value: int) -> None:
    con = get_connection(); cur = con.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO teams VALUES (?,?,?)",
        (name, ",".join(players), value),
    )
    con.commit(); con.close()


def load_team(name: str):
    con = get_connection(); cur = con.cursor()
    cur.execute("SELECT players,value FROM teams WHERE name=?", (name,))
    row = cur.fetchone(); con.close()
    return (row[0].split(","), row[1]) if row else None


def get_team_names() -> List[str]:
    con = get_connection(); cur = con.cursor()
    cur.execute("SELECT name FROM teams ORDER BY name")
    names = [n for (n,) in cur.fetchall()]
    con.close(); return names


def get_match_names() -> List[str]:
    con = get_connection(); cur = con.cursor()
    cur.execute("SELECT DISTINCT name FROM match ORDER BY name")
    names = [n for (n,) in cur.fetchall()]
    con.close(); return names


def get_match_player_row(match: str, player: str):
    con = get_connection(); con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM match WHERE name=? AND player=?", (match, player))
    row = cur.fetchone(); con.close()
    return dict(row) if row else None


# auto init when module imported
init_db()
