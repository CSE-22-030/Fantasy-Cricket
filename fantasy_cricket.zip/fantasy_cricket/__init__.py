"""Fantasy Cricket package marker and global constants."""
from pathlib import Path

DB_NAME = "fantasy_cricket.db"
DB_PATH = Path(__file__).parent / DB_NAME

__all__ = ["db", "scoring", "ui"]
