"""Fantasy cricket scoring rules implementation."""

def batting_points(runs: int, balls: int, fours: int, sixes: int) -> int:
    pts = runs // 2
    pts += 10 if runs >= 100 else 5 if runs >= 50 else 0
    if balls:
        sr = runs / balls * 100
        if 80 <= sr <= 100:
            pts += 2
        elif sr > 100:
            pts += 6  # 2 + extra 4
    pts += fours * 1 + sixes * 2
    return pts


def bowling_points(wkts: int, overs: float, maiden: int, runs_given: int) -> int:
    pts = wkts * 10
    pts += 10 if wkts >= 5 else 5 if wkts >= 3 else 0
    if overs:
        econ = runs_given / overs
        if 3.5 <= econ <= 4.5:
            pts += 4
        elif 2 <= econ < 3.5:
            pts += 7
        elif econ < 2:
            pts += 10
    return pts


def fielding_points(catch: int, stump: int, ro: int) -> int:
    return 10 * (catch + stump + ro)


def total_points(bat: dict, bowl: dict, fld: dict) -> int:
    return (
        batting_points(**bat)
        + bowling_points(**bowl)
        + fielding_points(**fld)
    )
