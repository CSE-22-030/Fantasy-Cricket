"""Tkinter GUI for Fantasy Cricket. Entry point: python -m fantasy_cricket.ui"""
from __future__ import annotations
import tkinter as tk
from tkinter import messagebox, simpledialog
from typing import List

from . import db, scoring

db.init_db()
TOTAL_PTS = 1000

class FantasyGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("Fantasy Cricket")
        self.team_name: str | None = None
        self.points_left = TOTAL_PTS
        self.points_used = 0
        self.cat_counts = {c: 0 for c in db.CATEGORIES}
        self.selected: List[str] = []
        self.cat_var = tk.StringVar(value="BAT")
        self._build_ui()
        self.refresh_available()

    # ---------- UI builders ------------
    def _build_ui(self):
        self._menu()
        self._summary()
        self._lists()

    def _menu(self):
        bar = tk.Menu(self.root)
        m = tk.Menu(bar, tearoff=0)
        m.add_command(label="NEW Team", command=self.new_team)
        m.add_command(label="OPEN Team", command=self.open_team)
        m.add_command(label="SAVE Team", command=self.save_team)
        m.add_command(label="EVALUATE Team", command=self.evaluate)
        bar.add_cascade(label="ManageTeams", menu=m)
        self.root.config(menu=bar)

    def _summary(self):
        f = tk.Frame(self.root); f.pack(fill=tk.X, pady=3)
        self.labels = {c: tk.Label(f, text=f"{c} 0") for c in db.CATEGORIES}
        for l in self.labels.values(): l.pack(side=tk.LEFT, padx=8)
        self.lbl_left = tk.Label(f, text=f"Points Avail {self.points_left}"); self.lbl_left.pack(side=tk.RIGHT, padx=8)
        self.lbl_used = tk.Label(f, text=f"Points Used {self.points_used}"); self.lbl_used.pack(side=tk.RIGHT, padx=8)

    def _lists(self):
        main = tk.Frame(self.root); main.pack(fill=tk.BOTH, expand=True, padx=10)
        # category selection & available list
        left = tk.Frame(main); left.pack(side=tk.LEFT)
        for c in db.CATEGORIES:
            tk.Radiobutton(left, text=c, variable=self.cat_var, value=c, command=self.refresh_available).pack(anchor='w')
        self.lb_avail = tk.Listbox(left, width=28, height=18); self.lb_avail.pack()
        self.lb_avail.bind('<Double-1>', lambda e: self.add())
        # middle arrows
        mid = tk.Frame(main); mid.pack(side=tk.LEFT, padx=4)
        tk.Button(mid, text='>', width=3, command=self.add).pack(pady=6)
        tk.Button(mid, text='<', width=3, command=self.remove).pack()
        # selected list
        right = tk.Frame(main); right.pack(side=tk.LEFT)
        self.lbl_team = tk.Label(right, text="Team Name"); self.lbl_team.pack()
        self.lb_sel = tk.Listbox(right, width=28, height=18); self.lb_sel.pack()
        self.lb_sel.bind('<Double-1>', lambda e: self.remove())

    # ---------- callbacks --------------
    def new_team(self):
        name = simpledialog.askstring("Team", "Enter team name:")
        if name:
            self.team_name = name
            self.lbl_team.config(text=f"Team Name {name}")
            self._reset()

    def open_team(self):
        names = db.get_team_names()
        if not names:
            messagebox.showinfo("Info", "No saved teams")
            return
        sel = simpledialog.askstring("Open", "Team name:", initialvalue=names[0])
        if not sel: return
        res = db.load_team(sel)
        if not res:
            messagebox.showerror("Error", "Team not found")
            return
        players, val = res
        self._reset(); self.team_name = sel; self.lbl_team.config(text=f"Team Name {sel}")
        self.points_left = TOTAL_PTS - val; self.points_used = val
        self.selected = players
        con = db.get_connection(); cur = con.cursor()
        for p in players:
            cur.execute("SELECT ctg FROM stats WHERE player=?", (p,)); self.cat_counts[cur.fetchone()[0]] += 1
        con.close()
        for p in players: self.lb_sel.insert(tk.END, p)
        self._update_labels(); self.refresh_available()

    def save_team(self):
        if not self.team_name:
            messagebox.showerror("Error", "Create a team first"); return
        if len(self.selected) != 11 or self.cat_counts['WK'] != 1:
            messagebox.showerror("Error", "Team must have 11 players incl. 1 WK"); return
        db.save_team(self.team_name, self.selected, self.points_used)
        messagebox.showinfo("Saved", "Team saved")

    def add(self):
        if not self.lb_avail.curselection(): return
        name, pts = self._parse(self.lb_avail.get(self.lb_avail.curselection()[0]))
        if name in self.selected or self.points_left < pts or len(self.selected) == 11:
            return
        con = db.get_connection(); cur = con.cursor(); cur.execute("SELECT ctg FROM stats WHERE player=?", (name,)); ctg = cur.fetchone()[0]; con.close()
        if ctg == 'WK' and self.cat_counts['WK'] >= 1:
            messagebox.showerror("Error", "Only one WK allowed"); return
        self.selected.append(name); self.lb_sel.insert(tk.END, name)
        self.points_left -= pts; self.points_used += pts; self.cat_counts[ctg] += 1
        self._update_labels(); self.refresh_available()

    def remove(self):
        if not self.lb_sel.curselection(): return
        name = self.lb_sel.get(self.lb_sel.curselection()[0])
        con = db.get_connection(); cur = con.cursor(); cur.execute("SELECT value, ctg FROM stats WHERE player=?", (name,)); pts, ctg = cur.fetchone(); con.close()
        self.selected.remove(name); self.lb_sel.delete(self.lb_sel.curselection()[0])
        self.points_left += pts; self.points_used -= pts; self.cat_counts[ctg] -= 1
        self._update_labels(); self.refresh_available()

    def evaluate(self):
        messagebox.showinfo("TODO", "Evaluation window not recreated in this minimalist version.")

    # ---------- helpers ---------------
    def refresh_available(self):
        self.lb_avail.delete(0, tk.END)
        for n, v in db.get_players(self.cat_var.get()):
            if n not in self.selected:
                self.lb_avail.insert(tk.END, f"{n} ({v})")

    def _update_labels(self):
        for c in db.CATEGORIES:
            self.labels[c].config(text=f"{c} {self.cat_counts[c]}")
        self.lbl_left.config(text=f"Points Avail {self.points_left}")
        self.lbl_used.config(text=f"Points Used {self.points_used}")

    def _reset(self):
        self.points_left, self.points_used = TOTAL_PTS, 0
        self.cat_counts = {c: 0 for c in db.CATEGORIES}
        self.selected.clear(); self.lb_sel.delete(0, tk.END)
        self._update_labels(); self.refresh_available()

    @staticmethod
    def _parse(entry: str):
        name, val = entry.rsplit("(", 1)
        return name.strip(), int(val[:-1])


def main():
    root = tk.Tk(); FantasyGUI(root); root.mainloop()


if __name__ == "__main__":
    main()
